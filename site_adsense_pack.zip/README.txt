Déposez tous ces fichiers dans /var/www/html/ ou le dossier racine de votre site web.

Une fois votre site validé, AdSense commencera à afficher automatiquement des annonces.